# Terrorism-Analysis


#### Objectives: 
* An elaborate exploratory data analysis on the dataset from the Global Terrorism Dataset.
* The analysis comprised of multiple questions which helped in deriving insights about terrorism hot spots and security questions
* This project was done as a part of the internship at the sparks Foundation


#### Packages Used:
* Pandas, Numpy, Matplotlib, Seaborn, Plotly

#### Questions:
* Total no of attacks in every year


* The 20 countries with most attacks
* Top 20 Countries with over 24 hour attacks
* Top 20 Countries where most people were killed
* Region-Wise attacks
<br/>

* Weapons used in most attacks
* Most Weapons Used across the years
* People killed by various weapons
* success vs unsuccess mirroring each other on the same axis.
* regions attacked across the years


<br/>

* most active terror groups
* kills by terror group
* weapons used by terror groups mostly
* nationality targetted by terror groups
<br/>

* Most Common Targets
* Target Types Attacked by most active terror groups

